<?php 
	// require '../clientobjects.php';
	// $sql = "select id from type order by weight ASC";
	// $result = $conn->exec($sql);
	// $types [];
	// while($row = mysql_fetch_array($result)){
	// 	$types[] = $row['id'];
	// }
	// print_r($types);
	echo 'hello world';
?>